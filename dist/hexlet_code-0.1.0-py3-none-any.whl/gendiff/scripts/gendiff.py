#!/usr/bin/env python

from gendiff.cli import parse


def main():
    args = parse()



if __name__ == '__main__':
    main()